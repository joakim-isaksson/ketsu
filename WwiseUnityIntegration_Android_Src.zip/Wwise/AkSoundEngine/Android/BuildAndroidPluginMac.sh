# //////////////////////////////////////////////////////////////////////
# //
# // Copyright (c) 2012 Audiokinetic Inc. / All Rights Reserved
# //
# //////////////////////////////////////////////////////////////////////

#! /bin/sh

Arch=${1?:"Usage: $0 Arch (e.g. armeabi-v7a) Configuration"}
Config=${2?:"Usage: $0 Arch Configuration (e.g., Debug, Profile, Release)"}

BuildPhase=PreBuild
OS=`uname`
if [[ ${OS} != 'Darwin' ]]; then
	echo "${BuildPhase}: The script is for Mac only. Do not run it on Cygwin."
	exit 1
fi


WwiseSdk="${WWISESDK}"
NdkBuild="${ANDROID_NDK_ROOT}"/ndk-build

ThisScriptDir="$( dirname "${BASH_SOURCE[0]}" )"
absScriptDir=$(cd "$ThisScriptDir"; pwd)
ProjectDir="${absScriptDir}"
CommonCodeDir="${ProjectDir}/../Common"

PlatformName=Android

CheckLogMsg="Check detailed logs under ${ProjectDir}/../../Logs"

"${NdkBuild}" -C "${ProjectDir}" V=1 clean AK_ARCH=${Arch} AK_CONFIG=${Config} AK_WWISESDK="${WwiseSdk}"
"${NdkBuild}" -C "${ProjectDir}" V=1 AK_ARCH=${Arch} AK_CONFIG=${Config} AK_WWISESDK="${WwiseSdk}"
if [[ "$?" != "0" ]]; then
	exit 1
fi

BuildDir="${ProjectDir}/libs/${Arch}"

echo "Prepare deployable Wwise Unity Integration: python ${CommonCodeDir}/DeployIntegration.py ${PlatformName} -c ${Config} -b ${BuildDir} -a ${Arch} (${CheckLogMsg}) ..."

python "${CommonCodeDir}/DeployIntegration.py" ${PlatformName} -c ${Config} -b ${BuildDir} -a ${Arch}
if [[ "$?" != "0" ]]; then
	exit 1
fi
